package com.billgym.pe.exeption;

public class DniDuplicadoExeption extends RuntimeException {
	public  DniDuplicadoExeption(String mensaje) {
		super(mensaje);
	}

}
